const puppeteer = require('puppeteer');
const cheerio = require('cheerio');
const fs = require('fs');
const https = require('https');

require('dotenv').config();

function delay(time) {
    return new Promise((resolve, reject) => {
        setTimeout(resolve, time);
    })
}

async function getPlayerStats() {
    try {
        const pageURL = 'https://www.ligue1.com/';

        const browser = await puppeteer.launch({ headless: false });
        const page = await browser.newPage();

        await page.setViewport({
            width: 1440,
            height: 1200,
        });

        await page.goto(pageURL, { waitUntil: ['load', 'domcontentloaded', 'networkidle0', 'networkidle2'] });

        await delay(2000);

        // 로그인 먼저, 데이터 로딩 방식 특성 상 로그인 필요 없을 듯
        // const loginIcon = await page.$('.Icon-proces');
        // loginIcon.evaluate((move) => move.click());

        // await page.waitForSelector('.Button-login');
        // const signInputs = await page.$$('input.FormMLC-input');

        // for (let input of signInputs) {
        //     input.evaluate((label) => {
        //         const inputType = label.type;

        //         if (inputType === 'text') label.value = 'dnfwlxo11@naver.com'
        //         else if (inputType === 'password') label.value = 'Dilim123@'
        //     });
        // }

        // await delay(2000);

        // const loginBtn = await page.$('button.Button-login');
        // loginBtn.evaluate((login) => login.click());

        // await page.waitForSelector('.HeaderNav-ligueAccName');
        
        const statTabHref = [
            'https://www.ligue1.com/stats',
            'https://www.ligue1.com/stats?StatsActiveTab=2',
            'https://www.ligue1.com/stats?StatsActiveTab=3',
            'https://www.ligue1.com/stats?StatsActiveTab=4',
            'https://www.ligue1.com/stats?StatsActiveTab=5',
        ]

        await page.goto(statTabHref[0]);
        await page.waitForSelector('.tabs-container');

        const statDetailBtns = await page.$$('.tabs-container .stats-card-container a');
        const statDetailHref = [];

        for (let statDetailBtn of statDetailBtns) statDetailHref.push(await statDetailBtn.evaluate((link) => link.href));

        console.log(statDetailHref)
    } catch (err) {
        console.error(err);
    }
}

getPlayerStats();