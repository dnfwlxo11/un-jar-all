const puppeteer = require('puppeteer');
const cheerio = require('cheerio');
const fs = require('fs');
const https = require('https');

function delay(time) {
    return new Promise((resolve, reject) => {
        setTimeout(resolve, time);
    })
}

async function getPlayerStats() {
    try {
        // 클럽 목록
        const pageURL = 'https://www.bundesliga.com/en/bundesliga/clubs';

        const browser = await puppeteer.launch({ headless: false });
        const page = await browser.newPage();

        await page.setViewport({
            width: 1440,
            height: 1200,
        });

        await page.goto(pageURL, { waitUntil: ['load', 'domcontentloaded', 'networkidle0', 'networkidle2'] });

        await delay(1000);

        const popupCloseBtn = await page.$('.banner-actions-container #onetrust-accept-btn-handler');
        await popupCloseBtn.click();

        await page.waitForSelector('body');

        // 팀 선택창에서 클릭하는 반복문
        const players = [];
        const teams = await page.$$('div.clubs club-card');
        const teamsHref = [];

        try {
            for (let team of teams) teamsHref.push(await team.$eval('a', (link) => link.href));

            const newHref = teamsHref.slice(3)
            for (let teamHref of newHref) {
                await page.goto(teamHref);

                // 팀 선택 후 선수들을 클릭하는 반복문
                await page.waitForSelector('div.playercard');
                
                let teamPlayers = await page.$$('div.playercard');
                const playersHref = [];

                for (let teamPlayer of teamPlayers) playersHref.push(await teamPlayer.$eval('a', (link) => link.href));
                await delay(2000);

                for (let playerHref of playersHref) {
                    await Promise.all([
                        page.waitForNavigation(),
                        page.goto(playerHref),
                        page.waitForSelector('section.stats'),
                    ]);

                    const playerPage = await page.content();
                    const player = cheerio.load(playerPage);

                    await delay(1000);

                    const playerInfo = {};

                    const playerFirstName = player('.playerInfo-basic .name .firstName').text().trim();
                    const playerLastName = player('.playerInfo-basic .name .lastName').text().trim();

                    playerInfo['name'] = `${playerFirstName} ${playerLastName}`;

                    const playerBasicStats = player('.playerInfo-extended .info');

                    playerBasicStats.each((idx, elem) => {
                        const key = player(elem).find('.label').text().toLowerCase().trim();
                        const value = player(elem).find('.value').text().toLowerCase().trim();

                        playerInfo[key] = value;
                    })

                    const playerAdvansedStats = player('.stats .player-stats-container .row');

                    await delay(2000);

                    playerAdvansedStats.each((idx, elem) => {
                        let key = player(elem).find('.key').text().toLowerCase().trim();
                        let value = Number(player(elem).find('.value').text().trim());

                        console.log(key, value, 'key, value')

                        if (!key) {
                            key = player(elem).find('stackedcolumn-chart .title').text().toLowerCase().trim();
                            value = `${player(elem).find('stackedcolumn-chart .value.unit.primary').text().trim()}/${player(elem).find('stackedcolumn-chart .value.unit.secondary').text().trim()}`
                        }

                        playerInfo[key] = value;
                    })

                    players.push(playerInfo);
                    console.log(playerInfo)
                    await delay(2000);
                }
            }

            const exportInformation = JSON.stringify({ 'data': players })
            const today = (new Date()).getTime()
            fs.writeFileSync(`./exports/${today}_bundes.json`, exportInformation)
        } catch (err) {
            console.error(err)
            const exportInformation = JSON.stringify({ 'data': players })
            const today = (new Date()).getTime()
            fs.writeFileSync(`./exports/${today}_bundes.json`, exportInformation)
        }
    } catch (err) {
        console.error(err);
    }
}

getPlayerStats();
